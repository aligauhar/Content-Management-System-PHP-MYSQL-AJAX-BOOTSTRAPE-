<?php echo "The freehosting is not allowing the _SESSION['variable'] function to work properly therefore you might not be able to see the user data in the CMS, "?>
<br>
<?php echo "you can only see the general view of the cms here, for better view go to the github link and run the project on xammp server Thanks!" ?>
<br><br>
<button style="float: left;" > <a href="index.php">Anyways! go to CMS</a> </button>
<button style="float: left;margin-left:3%; " > <a href="https://github.com/aligauhar/CMS-Web-in-PHP">GO to Github</a> </button>

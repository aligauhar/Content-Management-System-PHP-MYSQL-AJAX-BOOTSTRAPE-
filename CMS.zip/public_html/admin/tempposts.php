<?php echo "_SESSION['variable'] not working --- The All Post Panel looks like this" ?>
<br><br>
<button style="float: left;" > <a href="posts.php">GO to original View</a> </button>
<button style="float: left; margin-left:3%;" > <a href="../index.php">GO Back</a> </button>
<br><br>
<img width = "100%"; src="adminpanelimg.PNG" alt="image not found">
<!-- for establishing the connection to database -->
<?php
$conn = mysqli_connect("localhost","id20870278_cms","X1=ULdOyfrf!Bv0=","id20870278_cmsdatabase" ) or die ("error" . mysqli_error($conn));
?>
 <!-- includes the footer with the copy right and Tags -->
 <footer class="foo">
            <div class="row">
                <div class="col-lg-12">
                    <p style="text-align:center; font-family: 'Monotype Corsiva'; font-size:17px;"><i class="material-icons" style="color: brown;">@ COPYRIGHT</i> 2023 <b >CMS-Ali Gauhar</b></p>
                </div>
            </div>
   </footer>